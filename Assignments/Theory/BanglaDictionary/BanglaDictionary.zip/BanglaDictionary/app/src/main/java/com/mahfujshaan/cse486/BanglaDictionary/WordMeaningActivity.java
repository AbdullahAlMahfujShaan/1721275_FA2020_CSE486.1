package com.mahfujshaan.cse486.BanglaDictionary;

public class WordMeaningActivity {
}
